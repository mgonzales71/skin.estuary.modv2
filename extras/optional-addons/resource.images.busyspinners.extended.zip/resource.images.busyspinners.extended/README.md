# resource.images.busyspinners.titan-krypton

Kodi resource addon for skins that provides busy idicator textures (aka spinners) in Animated PNG (.apng) format. 

** Kodi 17 or higher REQUIRED **
